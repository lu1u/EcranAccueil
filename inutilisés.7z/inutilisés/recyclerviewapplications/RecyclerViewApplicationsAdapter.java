package com.lpi.ecrandaccueil.recyclerviewapplications;

import android.content.Context;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.lpi.ecrandaccueil.MainActivity2;
import com.lpi.ecrandaccueil.MessageBoxUtil;
import com.lpi.ecrandaccueil.R;
import com.lpi.ecrandaccueil.applications.ApplicationInstallee;
import com.lpi.ecrandaccueil.applications.ApplicationList;
import com.lpi.ecrandaccueil.sound.SoundManager;

public class RecyclerViewApplicationsAdapter extends RecyclerView.Adapter<RecyclerViewApplicationsAdapter.ViewHolder>
{

	private ApplicationList _applications;
	private LayoutInflater mInflater;
	private ItemClickListener mClickListener;
	private int _selectionnee = 0;

	// data is passed into the constructor
	public RecyclerViewApplicationsAdapter(Context context, ApplicationList applications )
	{
		this.mInflater = LayoutInflater.from(context);
		this._applications = applications ;
	}

	// inflates the row layout from xml when needed
	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
	{
		View view = mInflater.inflate(R.layout.element_liste_application, parent, false);
		return new ViewHolder(view);
	}

	// binds the data to the TextView in each row
	@Override
	public void onBindViewHolder(ViewHolder holder, int position)
	{
		ApplicationInstallee app = _applications.get(position);
		holder._tvNomAppliView.setText(app.getNom());

		app.setIcone(holder._ivIcone);
		holder._ivIcone.setSelected(_selectionnee == position);
	}

	@Override
	public void onAttachedToRecyclerView(final RecyclerView recyclerView)
	{
		super.onAttachedToRecyclerView(recyclerView);

		// Handle key up and key down and attempt to move selection
		recyclerView.setOnKeyListener(new View.OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();

				// Return false if scrolled to the bounds and allow focus to move off the list
				if (event.getAction() == KeyEvent.ACTION_DOWN)
				{
					if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
					{
						SoundManager.getInstance(v.getContext()).playDroite();
						return tryMoveSelection(lm, 1);
					}
					else if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT)
					{
						SoundManager.getInstance(v.getContext()).playGauche();
						return tryMoveSelection(lm, -1);
					}
				}

				return false;
			}
		});
	}

	private boolean tryMoveSelection(RecyclerView.LayoutManager lm, int direction) {
		int tryFocusItem = _selectionnee + direction;

		// If still within valid bounds, move the selection, notify to redraw, and scroll
		if (tryFocusItem >= 0 && tryFocusItem < getItemCount()) {
			notifyItemChanged(_selectionnee);
			_selectionnee = tryFocusItem;
			notifyItemChanged(_selectionnee);
			lm.scrollToPosition(_selectionnee);
			return true;
		}

		return false;
	}
	// total number of rows
	@Override
	public int getItemCount()
	{
		return _applications.getNb();
	}

	public @Nullable ApplicationInstallee getSelectedApplication()
	{
		if ( _selectionnee <0 || _selectionnee >=_applications.getNb())
			return null;

		return _applications.get(_selectionnee);
	}

	public void onMenu(@NonNull final Context context, final int itemId)
	{
		switch (itemId)
		{
			case R.id.action_debut:
				envoieAuDebut(context);
				break;
			case R.id.action_fin:
				envoieALaFin(context);
				break;
			case R.id.action_cacher:
				cacheApplication(context);
				break;
			//case R.id.action_relire:
			//	reinitApplications();
			//	break;
		}
	}

	/***
	 * Envoie l'application selectionnee au debut fin de la liste
	 */
	public void envoieAuDebut(@NonNull final Context context)
	{
		ApplicationInstallee app = _applications.get(_selectionnee);
		if (app == null)
			return;

		int maximum = Integer.MIN_VALUE + 1; // Important car on ajoutera 1 a la valeur
		for (ApplicationInstallee a : _applications.getApplications())
			if (a.getNbLancements() > maximum)
				maximum = a.getNbLancements();

		app.setNbLancements(maximum + 1);
		_applications.tri();
		this.notifyDataSetChanged();
		Toast.makeText(context, context.getString(R.string.message_application_debut, app.getNom()), Toast.LENGTH_SHORT).show();
	}

	public void envoieALaFin(@NonNull final Context context)
	{
		ApplicationInstallee app = _applications.get(_selectionnee);
		if (app == null)
			return;

		int minimum = Integer.MAX_VALUE - 1;
		for (ApplicationInstallee a : _applications.getApplications())
			if (a.getNbLancements() < minimum)
				minimum = a.getNbLancements();

		app.setNbLancements(minimum - 1);
		_applications.tri();
		this.notifyDataSetChanged();
		Toast.makeText(context, context.getString(R.string.message_application_fin, app.getNom()), Toast.LENGTH_SHORT).show();
	}

	public void cacheApplication(@NonNull final Context context)
	{
		ApplicationInstallee app = _applications.get(_selectionnee);
		if (app == null)
			return;

		MessageBoxUtil.messageBox(context, context.getString(R.string.messagebox_titre_cacher),
				context.getString(R.string.messagebox_cacher, app.getNom()), MessageBoxUtil.BOUTON_OK | MessageBoxUtil.BOUTON_CANCEL, new MessageBoxUtil.Listener()
				{
					@Override public void onOk()
					{
						app.setCachee(true);
						_applications.supprimeApplication(app);
						if (_selectionnee >= _applications.getNb())
							_selectionnee = _applications.getNb() - 1;
						RecyclerViewApplicationsAdapter.this.notifyDataSetChanged();
						Toast.makeText(context, context.getString(R.string.message_application_cachee, app.getNom()), Toast.LENGTH_SHORT).show();
					}

					@Override public void onCancel()
					{

					}
				}, app.getIcone());

	}

	/***
	 * Demarre l'application selectionnee
	 * @param context
	 */
	public void demarreApplication(@NonNull final Context context)
	{
		if (_selectionnee<0|| _selectionnee>=_applications.getNb())
			return;

		SoundManager.getInstance(context).playLance();
		_applications.demarre(_selectionnee, context);
		notifyDataSetChanged();
	}

	// stores and recycles views as they are scrolled off screen
	public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
	{
		TextView _tvNomAppliView;
		ImageView _ivIcone;

		ViewHolder(View itemView)
		{
			super(itemView);
			_tvNomAppliView = itemView.findViewById(R.id.tvNomAppli);
			_ivIcone = itemView.findViewById(R.id.ivIcone);
			itemView.setOnClickListener(this);
		}

		@Override
		public void onClick(View view)
		{
			if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
		}
	}


	// allows clicks events to be caught
	public void setClickListener(ItemClickListener itemClickListener)
	{
		this.mClickListener = itemClickListener;
	}

	// parent activity will implement this method to respond to click events
	public interface ItemClickListener
	{
		void onItemClick(View view, int position);
	}
}