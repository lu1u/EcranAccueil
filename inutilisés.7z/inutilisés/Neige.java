package com.lpi.ecrandaccueil;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Random;

public class Neige
{
	private static final int NB_FLOCONS = 400;
	private static final int NB_IMAGES = 2;
	private static final int TAILLE=150;
	private static final float DISTANCE_MIN = 1;
	private static final float DISTANCE_MAX = 10;

	private static class Flocon
	{
		public float distance ;
		public float x, y;
		public float vx, vy;
		public float taille;
		public int type;
	}

	public final @NonNull Drawable[] _images;

	private Flocon[] _flocons;
	private long _derniereFrame;

	public Neige(@Nullable final Context context)
	{
		_images = new Drawable[NB_IMAGES];
		_images[0] = context.getResources().getDrawable(R.drawable.snowflake);
		_images[0].setTint(Color.argb(64,255,255,255));
		_images[1] = context.getResources().getDrawable(R.drawable.snowflake2);
		_images[1].setTint(Color.argb(64,255,255,255));

		_derniereFrame = System.currentTimeMillis();
	}

	void creerFlocons(int largeur, int hauteur)
	{
		Random r = new Random(_derniereFrame);
		_flocons = new Flocon[NB_FLOCONS];
		for ( int i = 0; i < NB_FLOCONS;i++)
		{
			_flocons[i] = new Flocon();
			_flocons[i].distance = floatRandom(r, DISTANCE_MIN, DISTANCE_MAX);
			_flocons[i].x = r.nextInt(largeur);
			_flocons[i].y = r.nextInt(hauteur);
			_flocons[i].vx = floatRandom( r, -10f, 10f)/ _flocons[i].distance;
			_flocons[i].vy = floatRandom( r, 40.0f, 60.0f)/ _flocons[i].distance;
			_flocons[i].type = r.nextInt(NB_IMAGES);
			_flocons[i].taille = TAILLE/ _flocons[i].distance;
		}
	}
	private float floatRandom(final @NonNull Random r, final float min, final float max)
	{
		return min + r.nextFloat() * (max-min);
	}

	public void Affiche(@NonNull final Canvas canvas, int largeur, int hauteur)
	{
		if ( _flocons==null)
			creerFlocons(largeur, hauteur);
		Random r = new Random(_derniereFrame);
		long maintenant = System.currentTimeMillis();
		float dt = (float)(maintenant-_derniereFrame) /1000.0f;
		for ( Flocon f : _flocons)
		{
			// Bouge le flocon
			f.x += f.vx * dt;
			f.y += f.vy * dt;
			if ( f.y > hauteur)
				f.y = -TAILLE;
			if ( f.x > largeur)
				f.x = - f.taille;
			if ( f.x + f.taille< 0)
				f.x = largeur;

			f.vx += floatRandom( r, -10f, 10f)*dt / f.distance ;
			_images[f.type].setBounds((int)f.x, (int)f.y, (int)(f.x +f.taille), (int)(f.y + f.taille));
			_images[f.type].draw(canvas);
		}

		_derniereFrame = maintenant;
	}

}
