package com.lpi.ecrandaccueil.service;

import android.view.KeyEvent;

import androidx.annotation.NonNull;

import java.util.HashMap;

public class KeyTable
{
	static final HashMap<Integer, String> _touches;
	static
	{
		_touches = new HashMap<>();
		_touches.put( 3, "Home");
		_touches.put( 4, "Retour");
		_touches.put( 21, "Gauche");
		_touches.put( 22, "Droite");
		_touches.put( 19, "Haut");
		_touches.put( 20, "Bas");
		_touches.put( 23, "Centre");
		_touches.put( 86, "Stop");
		_touches.put( 89, "Retour rapide");
		_touches.put( 90, "Avance rapide");
		_touches.put( 126, "Play");
		_touches.put( 127, "Pause");
		_touches.put( 130, "Enregistre");
		_touches.put( 165, "Info");
		_touches.put( 176, "Menu");
		_touches.put( 178, "Entrées");
		_touches.put( 183, "Rouge");
		_touches.put( 184, "Vert");
		_touches.put( 185, "Jaune");
		_touches.put( 186, "Bleu");
		_touches.put( 189, "2");
		_touches.put( 190, "3");
		_touches.put( 191, "4");
		_touches.put( 192, "5");
		_touches.put( 193, "6");
		_touches.put( 194, "7");
		_touches.put( 195, "8");
		_touches.put( 196, "9");
		_touches.put( 197, "0");
		_touches.put( 233, "Texte");
		_touches.put( 249, "Prime");
		_touches.put( 265, "Netflix");
		_touches.put( 267, "Chaines");
	}

	public static String getLabel(@NonNull final KeyEvent event)
	{
		char label = event.getDisplayLabel();
		if( label != '\0')
			return "" + label;

		int unicode = event.getUnicodeChar();
		if  (unicode != 0)
			return "" + (char)unicode;

		return _touches.getOrDefault(event.getKeyCode(), Integer.toString(event.getKeyCode()));
	}
}
