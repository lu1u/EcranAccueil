package com.lpi.ecrandaccueil.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.lpi.ecrandaccueil.MessageBoxUtil;
import com.lpi.ecrandaccueil.Preferences;

import java.util.Map;

public class TVLauncherService extends AccessibilityService
{

	public static final String TV_LAUNCHER_SERVICE = "TVLauncherService";
	public static final String TVLAUNCHERSERVICE_COMMANDE = "com.lpi.ecrandaccueil.tvlauncherservice.action";
	public static final String TVLAUNCHERSERVICE_PARAMETRE = "com.lpi.ecrandaccueil.tvlauncherservice.parametre";
	public static final String KEYCODE = "KeyCode";
	public static final String KEYLABEL = "KeyLabel";

	public static final int MODE_STOP = 0;
	public static final int MODE_ASSOCIATE = 1;
	public static final int MODE_BACKGROUND = 2;

	private int _mode = MODE_BACKGROUND;

	public static void switchToBackgroundMode(@NonNull final Context context)
	{
		Intent serviceIntent = new Intent(context, TVLauncherService.class);
		serviceIntent.setAction(TVLAUNCHERSERVICE_COMMANDE);
		serviceIntent.putExtra(TVLAUNCHERSERVICE_PARAMETRE, MODE_BACKGROUND);
		context.startService(serviceIntent); // => onStartCommand
	}

	public static void switchToAssociateMode(@NonNull final Context context)
	{
		Intent serviceIntent = new Intent(context, TVLauncherService.class);
		serviceIntent.setAction(TVLAUNCHERSERVICE_COMMANDE);
		serviceIntent.putExtra(TVLAUNCHERSERVICE_PARAMETRE, MODE_ASSOCIATE);
		context.startService(serviceIntent); // => onStartCommand
	}


	/***
	 * Demarrage du service avec un parametre (envoi d'un parametre au service)
	 * @param intent
	 * @param flags
	 * @param startId
	 * @return
	 */
	@Override public int onStartCommand(final Intent intent, final int flags, final int startId)
	{
		String action = intent.getAction();
		if (TVLAUNCHERSERVICE_COMMANDE.equals(action))
		{
			_mode = intent.getIntExtra(TVLAUNCHERSERVICE_PARAMETRE, _mode);
		}
		return super.onStartCommand(intent, flags, startId);
	}

	/***
	 * Reception d'un evenement touche
	 * @param event
	 * @return
	 */
	@Override public boolean onKeyEvent(KeyEvent event)
	{
		int action = event.getAction();
		if (action == KeyEvent.ACTION_UP)
		{
			switch (_mode)
			{
				case MODE_ASSOCIATE:
					return avertiActivity(event.getKeyCode(), KeyTable.getLabel(event));

				case MODE_BACKGROUND:
					return interceptKey(event);

				default:
					// Ne fait rien
			}
		}
		return super.onKeyEvent(event);
	}

	/***
	 * Intercepte une touche, lance une application si associée à une application
	 * @param event
	 * @return
	 */
	public boolean interceptKey(final KeyEvent event)
	{
		int keycode = event.getKeyCode();
		try
		{
			String packageName = getPackageNameFromKeyCode(keycode);
			if (packageName == null)
			{
				Toast.makeText(this, "Touche non associée " + KeyTable.getLabel(event), Toast.LENGTH_SHORT).show();
				return false;
			}

			PackageManager pm = getPackageManager();
			Intent intent = pm.getLaunchIntentForPackage(packageName);
			if (intent != null)
			{
				_mode = MODE_STOP;
				MessageBoxUtil.messageBox(this, "Raccourci", "Touche " + KeyTable.getLabel(event) + " => " + packageName, MessageBoxUtil.BOUTON_OK, new MessageBoxUtil.Listener()
				{
					@Override public void onOk()
					{
						_mode = MODE_BACKGROUND;
					}

					@Override public void onCancel()
					{
						_mode = MODE_BACKGROUND;
					}
				}, null);
				//startActivity(intent);
				return true;
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return false;
	}

	/***
	 * Retrouve l'application associee a un raccourci, ou null
	 * @param keycode
	 * @return
	 */
	private @Nullable String getPackageNameFromKeyCode(final int keycode)
	{
		Map<String, ?> allEntries = Preferences.getInstance(this).allKeys();
		for (Map.Entry<String, ?> entry : allEntries.entrySet())
		{
			String key = entry.getKey();
			if (key.startsWith(Preferences.PREF_RACCOURCI))
			{
				Object o = entry.getValue();
				if (o instanceof Integer)
				{
					int raccourci = (int) o;
					if (keycode == raccourci)
					{
						// On est tombé sur la bonne application
						String[] tokens = key.split(Preferences.SEPARATEUR_REGEXP);
						if (tokens.length > 1)
						{
							return tokens[1];
						}
					}
				}
			}
		}
		return null;
	}

	/***
	 * Envoie la touche interceptee a l'activite
	 * @param keycode
	 * @param displayLabel
	 * @return
	 */
	private boolean avertiActivity(int keycode, String displayLabel)
	{
		try
		{
			Intent intent = new Intent(TV_LAUNCHER_SERVICE);
			intent.putExtra(KEYCODE, keycode);
			intent.putExtra(KEYLABEL, displayLabel);
			getApplicationContext().sendBroadcast(intent);
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return true;
	}

	/**
	 * Passes information to AccessibilityServiceInfo.
	 */
	//@Override
	//public void onServiceConnected()
	//{
	//	Log.v(TAG, "on Service Connected");
	//	AccessibilityServiceInfo info = new AccessibilityServiceInfo();
	//	info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
	//	info.notificationTimeout = 100;
	//	info.feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN;
	//	info.flags = Accessibility
	//	setServiceInfo(info);
////
	//}// end onServiceConnected

	/**
	 * Called on an interrupt.
	 */
	@Override
	public void onInterrupt()
	{
	}

	//@Override
	public void onAccessibilityEvent(AccessibilityEvent event)
	{
//		final int eventType = event.getEventType();
//		switch (eventType)
//		{
//			case AccessibilityEvent.TYPE_VIEW_CLICKED:
//				//		do somthing
//				//avertiActivity( "onAccessibilityEvent action:" + event.getAction() + ",type:" + event.getEventType());
//				break;
//			case AccessibilityEvent.TYPE_VIEW_FOCUSED:
//				//		do somthing
//				break;
//		}
	}
}
