package com.lpi.ecrandaccueil;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lpi.ecrandaccueil.applications.ApplicationInstallee;
import com.lpi.ecrandaccueil.applications.ApplicationList;
import com.lpi.ecrandaccueil.customviews.AnimationView;
import com.lpi.ecrandaccueil.recyclerviewapplications.RecyclerViewApplicationsAdapter;
import com.lpi.ecrandaccueil.sound.SoundManager;

public class MainActivity2 extends AppCompatActivity implements View.OnLongClickListener
{
	public static final String TAG = "MainActivity2";

	RecyclerView _rvApplications;
	RecyclerViewApplicationsAdapter _adapter;
	ImageButton _ibSettings;
	ProgressBar _progressBar;
	AnimationView _animation;
	private AnimationDrawable _animationDrawable;

	@Override protected void onResume()
	{
		super.onResume();
		setFullScreen(this);
		if (_animation != null)
			_animation.onResume();

		View layoutView = this.findViewById(R.id.layout);
		_animationDrawable = (AnimationDrawable) layoutView.getBackground();
		_animationDrawable.setEnterFadeDuration(10);
		_animationDrawable.setExitFadeDuration(5000);
		_animationDrawable.start();
	}

	@Override protected void onPause()
	{
		super.onPause();
		if (_animation != null)
			_animation.onPause();
		if (_animationDrawable != null)
		{
			_animationDrawable.stop();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);
		setFullScreen(this);
		Preferences.getInstance(this); // Pour initialiser le singleton

		_rvApplications = findViewById(R.id.rvApplications);
		_ibSettings = findViewById(R.id.imageButtonSettings);
		_progressBar = findViewById(R.id.progressBar);
		_animation = findViewById(R.id.animationView2);
		_ibSettings.setVisibility(View.GONE);
		_rvApplications.setVisibility(View.GONE);
		_progressBar.setVisibility(View.VISIBLE);

		_ibSettings.setOnClickListener(view ->
		{
			openContextMenu(_ibSettings);
		});
		initApplications();

		registerForContextMenu(_rvApplications);
		registerForContextMenu(_ibSettings);

		SoundManager.getInstance(this);
	}

	private void initApplications()
	{
		_rvApplications.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
		_rvApplications.setOnLongClickListener(this);

		AsyncTask t = new AsyncTask()
		{
			@Override protected Object doInBackground(final Object[] objects)
			{
				ApplicationList.ListeListener listener = () ->
				{
					_rvApplications.invalidate();
				};

				ApplicationList applications = new ApplicationList(listener);
				applications.litApplications(MainActivity2.this, false);
				_adapter = new RecyclerViewApplicationsAdapter(MainActivity2.this, applications);
				return null;
			}

			@Override protected void onPostExecute(final Object o)
			{
				super.onPostExecute(o);
				//_adapter.setClickListener(MainActivity2.this);
				_rvApplications.setAdapter(_adapter);
				_rvApplications.invalidate();

				_ibSettings.setVisibility(View.VISIBLE);
				_rvApplications.setVisibility(View.VISIBLE);
				_progressBar.setVisibility(View.GONE);
			}

		};
		t.execute();

	}

	/***
	 * Clic sur un item de la liste d'applications
	 * @param view
	 */
	public void onClickListApplications(View view)
	{
		_adapter.demarreApplication(this);
	}

	@Override public boolean onLongClick(final View view)
	{
		openContextMenu(_rvApplications);

		return true;
	}

	public void onClickButtonSettings(View v)
	{
		openContextMenu(_ibSettings);
	}

	@Override
	public void onCreateContextMenu(final @NonNull ContextMenu menu, final @NonNull View v, final @NonNull ContextMenu.ContextMenuInfo menuInfo)
	{
		super.onCreateContextMenu(menu, v, menuInfo);
		if (v == _rvApplications)
		{
			ApplicationInstallee a = _adapter.getSelectedApplication();
			if (a != null)
			{
				getMenuInflater().inflate(R.menu.applications_menu, menu);
				MenuCompat.setGroupDividerEnabled(menu, true);
				menu.setHeaderTitle(a.getNom());
				menu.setHeaderIcon(a.getIcone());
			}
		}
		else
		{
			if (v == _ibSettings)
			{
				getMenuInflater().inflate(R.menu.menu_settings, menu);
				MenuCompat.setGroupDividerEnabled(menu, true);
				MenuItem item = menu.findItem(R.id.menu_son);
				SoundManager sm = SoundManager.getInstance(this);
				item.setChecked(sm.getVolume() > 0);
			}
		}
	}

	@Override public void onContextMenuClosed(@NonNull final Menu menu)
	{
		super.onContextMenuClosed(menu);
		_rvApplications.requestFocus();
	}

	@Override public boolean onContextItemSelected(@NonNull final MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.menu_son:
				onMenuSon();
				break;
			case R.id.menu_a_propos:
				onMenuAPropos();
				break;

			case R.id.menu_parametres:
				onMenuParametres();
				break;

			case R.id.menu_relire:
				onRelireApplications();
				break;
			default:
				_adapter.onMenu(this, item.getItemId());
				_rvApplications.requestFocus();
		}
		return true;
	}

	private void onRelireApplications()
	{
		ApplicationList applications = new ApplicationList(new ApplicationList.ListeListener()
		{
			@Override public void onListeChanged()
			{

			}
		});
		applications.litApplications(MainActivity2.this, true);
		_adapter = new RecyclerViewApplicationsAdapter(MainActivity2.this, applications);
		_rvApplications.setAdapter(_adapter);
	}

	private void onMenuParametres()
	{
		startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
	}

	private void onMenuAPropos()
	{
		DialogAPropos.start(this);
	}

	private void onMenuSon()
	{
		SoundManager sm = SoundManager.getInstance(this);
		sm.inverseSon();
	}

	public static void setFullScreen(@NonNull final Activity a)
	{
		try
		{
			if (Build.VERSION.SDK_INT < 19)
			{
				a.getWindow().setFlags(
						WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER,
						WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER
				                      );
			}
			else
			{
				View decorView = a.getWindow().getDecorView();

				int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
						| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
						| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
						| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
						| View.SYSTEM_UI_FLAG_FULLSCREEN // hide status bar
						| View.SYSTEM_UI_FLAG_IMMERSIVE;

				decorView.setSystemUiVisibility(uiOptions);

				a.getWindow().setFlags(
						WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER,
						WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER
				                      );
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}