package com.lpi.ecrandaccueil.medias;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.lpi.ecrandaccueil.FileUtils;

import java.io.File;

public class Fichier
{
	protected String _nom;
	protected String _chemin;
	protected File _file;
	private Drawable _icone;

	public Fichier(@NonNull final File fichier)
	{
		_file = fichier;
		_chemin = fichier.getAbsolutePath();
		_nom = fichier.getName();
	}

	public @NonNull final String Nom()
	{
		return _nom;
	}

	public @NonNull final String chemin() { return _chemin; }

	public void setIcon(@NonNull final Context context, @NonNull final ImageView img)
	{
		if (_icone == null)
			_icone = FileUtils.getIcon(context, _chemin);

		if (_icone != null)
			img.setImageDrawable(_icone);
	}

	public boolean isDirectory()
	{
		return false;
	}


	public File file()
	{
		return _file;
	}
}
