package com.lpi.ecrandaccueil.medias;

import android.content.Context;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.lpi.ecrandaccueil.Preferences;
import com.lpi.ecrandaccueil.R;

import java.io.File;
import java.util.ArrayList;

public class MediaAdapter extends ArrayAdapter<Fichier>
{

	private static String _path;

	public MediaAdapter(Context context, ArrayList<Fichier> fichiers)
	{

		super(context, 0, fichiers);

	}

	public static MediaAdapter createAdapter(final @NonNull Context context, @Nullable String repertoire)
	{
		ArrayList<Fichier> fichiers = new ArrayList<>();

		Preferences preferences = Preferences.getInstance(context);

		if ( repertoire == null)
		{
			_path = preferences.getString(Preferences.PREF_REPERTOIRE_COURANT, Environment.getExternalStorageDirectory().toString());
		}
		else
			_path = repertoire;
		preferences.setString(Preferences.PREF_REPERTOIRE_COURANT, _path);

		File directory = new File(_path);
		if ( directory.getParent()!=null)
			fichiers.add(new RepertoireParent(directory));

		File[] files = directory.listFiles();
		if (files != null)
			for (File f : files)
			{
				if ( f.canRead())
				{
					if (f.isDirectory())
						fichiers.add(new Repertoire(f));
					else
						fichiers.add(new Fichier(f));
				}
			}
		return new MediaAdapter(context, fichiers);
	}

	@Override

	public View getView(int position, View convertView, ViewGroup parent)
	{

		// Get the data item for this position

		Fichier fichier = getItem(position);

		// Check if an existing view is being reused, otherwise inflate the view

		if (convertView == null)
			convertView = LayoutInflater.from(getContext()).inflate(R.layout.element_liste_medias, parent, false);

		// Lookup view for data population
		TextView libelle = convertView.findViewById(R.id.textViewLibelle);
		ImageView image = convertView.findViewById(R.id.imageViewIcone);

		libelle.setText(fichier.Nom());
		fichier.setIcon(getContext(), image);
		// Return the completed view to render on screen

		return convertView;

	}

	public String chemin()
	{
		return _path ;
	}
}
