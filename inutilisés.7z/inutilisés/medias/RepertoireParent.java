package com.lpi.ecrandaccueil.medias;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.lpi.ecrandaccueil.R;

import java.io.File;

public class RepertoireParent extends Repertoire
{
	static private Drawable _iconeParent;
	public RepertoireParent(@NonNull final File fichier)
	{
		super(fichier.getParentFile());

		_nom = "..";
	}

	public void setIcon(@NonNull final Context context, @NonNull final ImageView img)
	{
		if (_iconeParent == null)
			_iconeParent = context.getDrawable(R.drawable.repertoire_parent);

		if (_iconeParent != null)
			img.setImageDrawable(_iconeParent);
	}
}
