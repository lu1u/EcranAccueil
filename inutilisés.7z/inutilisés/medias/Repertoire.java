package com.lpi.ecrandaccueil.medias;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.lpi.ecrandaccueil.FileUtils;
import com.lpi.ecrandaccueil.R;

import java.io.File;

public class Repertoire extends Fichier
{
	static private Drawable _iconeRepertoire = null;
	public Repertoire(@NonNull final File fichier)
	{
		super(fichier);
	}

	public void setIcon(@NonNull final Context context, @NonNull final ImageView img)
	{
		if (_iconeRepertoire == null)
			_iconeRepertoire = context.getDrawable(R.drawable.repertoire);

		if (_iconeRepertoire != null)
			img.setImageDrawable(_iconeRepertoire);
	}

	public boolean isDirectory()
	{
		return true;
	}
}
