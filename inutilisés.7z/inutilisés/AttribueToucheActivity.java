package com.lpi.ecrandaccueil;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.lpi.ecrandaccueil.applications.ApplicationInstallee;
import com.lpi.ecrandaccueil.applications.ApplicationList;
import com.lpi.ecrandaccueil.service.TVLauncherService;

public class AttribueToucheActivity extends AppCompatActivity
{
	interface AttribueToucheActivityListener
	{
		void onFinished();
	}

	public static void Start(@NonNull final Activity context, @NonNull final ApplicationInstallee application, @NonNull final ApplicationList applications, @NonNull final AttribueToucheActivityListener listener)
	{
		try
		{
			TVLauncherService.switchToAssociateMode(context);
			final AlertDialog dialogBuilder = new AlertDialog.Builder(context).create();

			LayoutInflater inflater = context.getLayoutInflater();
			final View dialogView = inflater.inflate(R.layout.activity_attribue_touche, null);

			// Controles de la fenetre
			TextView _tvNom = dialogView.findViewById(R.id.textViewApplicationName);
			TextView _tvPackage = dialogView.findViewById(R.id.textViewPackageName);
			TextView _tvRaccourci = dialogView.findViewById(R.id.textViewRaccourci);
			ImageView _imageView = dialogView.findViewById(R.id.imageViewIcone);

			// Initialiser les controles

			_tvNom.setText(application.getNom());
			_tvPackage.setText(application.getPackageName());
			_tvRaccourci.setText(Integer.toString(application.getRaccourci()));
			_imageView.setImageDrawable(context.getPackageManager().getApplicationIcon(application.getPackageName()));

			// Recepteur pour les evenements telecommande
			IntentFilter filter = new IntentFilter();
			filter.addAction(TVLauncherService.TV_LAUNCHER_SERVICE);
			BroadcastReceiver messageReceiver = new BroadcastReceiver()
			{
				@Override
				public void onReceive(Context context, Intent intent)
				{
					receiveKey(context, intent, application, dialogBuilder, applications);
				}
			};
			context.registerReceiver(messageReceiver, filter);

			// Recepteur de fermeture, pour etre sur de remettre le service en mode Background
			dialogBuilder.setOnDismissListener(dialogInterface ->
			{
				TVLauncherService.switchToBackgroundMode(context);
				listener.onFinished();
			});

			////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			// Afficher la fenetre
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			dialogBuilder.setView(dialogView);
			dialogBuilder.show();
		} catch (Exception e)
		{
			MessageBoxUtil.messageBox(context, "Erreur", e.getMessage(), MessageBoxUtil.BOUTON_OK, null, null);
		}

	}

	private static void receiveKey(final Context context, final Intent intent, final ApplicationInstallee application, final AlertDialog dialogBuilder, @NonNull final ApplicationList applications)
	{
		if (TVLauncherService.TV_LAUNCHER_SERVICE.equals(intent.getAction()))
		{
			int keyCode = intent.getIntExtra(TVLauncherService.KEYCODE, ApplicationInstallee.RACCOURCI_INVALIDE);
			if ( keyCode == KeyEvent.KEYCODE_BACK)
			{
				// Annulation par touche Retour
				dialogBuilder.dismiss();
				return;
			}

			String keyLabel = intent.getStringExtra(TVLauncherService.KEYLABEL) ;
			if (keyCode != ApplicationInstallee.RACCOURCI_INVALIDE)
			{
				ApplicationInstallee a = applications.getToucheAssociee(keyCode);
				if (a != null && a != application)
				{
					TVLauncherService.switchToBackgroundMode(context);
					// Touche deja associee
					MessageBoxUtil.messageBox(context, "Touche déjà associée", "La touche [" + keyLabel + "] est déjà associée à l'application " + a.getNom() + ". Voulez-vous changer et l'associer à l'application " + application.getNom() + "?",
							MessageBoxUtil.BOUTON_OK | MessageBoxUtil.BOUTON_CANCEL, new MessageBoxUtil.Listener()
							{
								@Override public void onOk()
								{
									// Associer a l'application
									application.setRaccourci(keyCode, keyLabel);
									TVLauncherService.switchToBackgroundMode(context);
									dialogBuilder.dismiss();
								}

								@Override public void onCancel()
								{
									TVLauncherService.switchToAssociateMode(context);

								}
							}, null);
				}
				else
				{
					TVLauncherService.switchToBackgroundMode(context);
					// Touche pas encore associee
					MessageBoxUtil.messageBox(context, "Associer une touche", "Voulez-vous associer la touche [" + keyLabel + "] à l'application " + application.getNom() + "?",
							MessageBoxUtil.BOUTON_OK | MessageBoxUtil.BOUTON_CANCEL, new MessageBoxUtil.Listener()
							{
								@Override public void onOk()
								{
									// Associer a l'application
									application.setRaccourci(keyCode, keyLabel);
									TVLauncherService.switchToBackgroundMode(context);
									dialogBuilder.dismiss();
								}

								@Override public void onCancel()
								{
									TVLauncherService.switchToAssociateMode(context);
								}
							}, null);
				}
			}
		}
	}

}